package com.nightbrowse.app

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.DownloadManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.nightbrowse.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var tabManager: TabManager
    
    private var isIncognito = false
    private var currentSearchEngine = "https://duckduckgo.com/?q="
    private val bookmarks = mutableListOf<String>()
    private val history = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        tabManager = TabManager(this)
        setupNewTab()
        setupUIListeners()
    }

    private fun setupNewTab() {
        val webView = tabManager.createNewTab { createConfiguredWebView() }
        binding.webViewContainer.removeAllViews()
        binding.webViewContainer.addView(webView)
        webView.loadUrl("https://duckduckgo.com")
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createConfiguredWebView(): WebView {
        return WebView(this).apply {
            layoutParams = android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT
            )
            
            webViewClient = NightWebViewClient(
                onPageLoadStarted = {
                    binding.loadingProgress.visibility = View.VISIBLE
                    binding.loadingProgress.setProgress(30, true)
                },
                onPageLoadFinished = { url ->
                    binding.loadingProgress.visibility = View.GONE
                    binding.urlEditText.setText(url)
                    url?.let { if(!isIncognito) history.add(it) }
                }
            )

            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                    binding.loadingProgress.setProgress(newProgress, true)
                }
            }

            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                cacheMode = if (isIncognito) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
                setSupportMultipleWindows(false)
                javaScriptCanOpenWindowsAutomatically = false
            }

            setLayerType(View.LAYER_TYPE_HARDWARE, null)

            if (androidx.webkit.WebViewFeature.isFeatureSupported(androidx.webkit.WebViewFeature.ALGORITHMIC_DARKENING)) {
                androidx.webkit.WebSettingsCompat.setAlgorithmicDarkeningAllowed(settings, true)
            }

            setDownloadListener { url, userAgent, contentDisposition, mimetype, _ ->
                try {
                    val request = DownloadManager.Request(Uri.parse(url)).apply {
                        setMimeType(mimetype)
                        addRequestHeader("User-Agent", userAgent)
                        setDescription("Downloading file from NightBrowse...")
                        setTitle("NightBrowse_Download")
                        setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                        setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "NightBrowse_File")
                    }
                    val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
                    dm.enqueue(request)
                    Toast.makeText(context, "Download dimulai...", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(context, "Download gagal: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun setupUIListeners() {
        binding.urlEditText.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                val input = binding.urlEditText.text.toString()
                executeSearchOrUrl(input)
                true
            } else false
        }

        binding.btnRefresh.setOnClickListener {
            tabManager.getCurrentTab()?.reload()
        }

        binding.bottomNavigation.setOnItemSelectedListener { item ->
            val currentWeb = tabManager.getCurrentTab()
            when (item.itemId) {
                R.id.nav_back -> {
                    if (currentWeb?.canGoBack() == true) currentWeb.goBack()
                    else Toast.makeText(this, "Tidak ada riwayat kembali", Toast.LENGTH_SHORT).show()
                }
                R.id.nav_forward -> {
                    if (currentWeb?.canGoForward() == true) currentWeb.goForward()
                }
                R.id.nav_tabs -> showTabManagementMenu()
                R.id.nav_reader -> triggerReaderMode()
                R.id.nav_menu -> showSettingsControlPanel()
            }
            true
        }
    }

    private fun executeSearchOrUrl(input: String) {
        val cleanInput = input.trim()
        val targetUrl = if (cleanInput.startsWith("http://") || cleanInput.startsWith("https://")) {
            cleanInput
        } else if (cleanInput.contains(".") && !cleanInput.contains(" ")) {
            "https://$cleanInput"
        } else {
            currentSearchEngine + cleanInput
        }
        tabManager.getCurrentTab()?.loadUrl(targetUrl)
    }

    private fun triggerReaderMode() {
        val jsReaderScript = """
            (function() {
                var articleText = "";
                var paragraphs = document.querySelectorAll('p, h1, h2, h3');
                paragraphs.forEach(function(p) {
                    articleText += p.outerHTML;
                });
                document.body.innerHTML = "<div style='background-color:#0D0D11;color:#F3F4F6;padding:25px;font-family:sans-serif;line-height:1.6;'>" + articleText + "</div>";
            })();
        """.trimIndent()
        tabManager.getCurrentTab()?.evaluateJavascript(jsReaderScript, null)
        Toast.makeText(this, "Reader Mode Diaktifkan", Toast.LENGTH_SHORT).show()
    }

    private fun showTabManagementMenu() {
        val options = arrayOf("Tambah Tab Baru", "Tab Aktif Saat Ini (${tabManager.getTabCount()})", "Reset Semua Tab")
        AlertDialog.Builder(this)
            .setTitle("Manajer Tab NightBrowse")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> setupNewTab()
                    1 -> Toast.makeText(this, "Berada di tab indeks: ${tabManager.currentTabIndex}", Toast.LENGTH_SHORT).show()
                    2 -> {
                        tabManager = TabManager(this)
                        setupNewTab()
                    }
                }
            }.show()
    }

    private fun showSettingsControlPanel() {
        val items = arrayOf(
            "AdBlocker Bawaan: ${if(AdBlocker.isEnabled) "ON" else "OFF"} (Diblokir: ${AdBlocker.adsBlockedCount})",
            "Mode Incognito: ${if(isIncognito) "ON" else "OFF"}",
            "Ganti Mesin Pencari (DuckDuckGo / Google)",
            "Tambah ke Bookmark",
            "Lihat History Kunjungan"
        )

        AlertDialog.Builder(this)
            .setTitle("Pengaturan NightBrowse")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> {
                        AdBlocker.isEnabled = !AdBlocker.isEnabled
                        Toast.makeText(this, "AdBlocker diubah: ${AdBlocker.isEnabled}", Toast.LENGTH_SHORT).show()
                    }
                    1 -> {
                        isIncognito = !isIncognito
                        binding.incognitoIndicator.visibility = if (isIncognito) View.VISIBLE else View.GONE
                        if(isIncognito) {
                            CookieManager.getInstance().removeAllCookies(null)
                            tabManager.getCurrentTab()?.clearCache(true)
                        }
                        Toast.makeText(this, "Incognito Mode: $isIncognito", Toast.LENGTH_SHORT).show()
                    }
                    2 -> {
                        currentSearchEngine = if(currentSearchEngine.contains("duckduckgo")) {
                            "https://www.google.com/search?q="
                        } else {
                            "https://duckduckgo.com/?q="
                        }
                        Toast.makeText(this, "Mesin Pencari diatur ke: $currentSearchEngine", Toast.LENGTH_SHORT).show()
                    }
                    3 -> {
                        tabManager.getCurrentTab()?.url?.let {
                            bookmarks.add(it)
                            Toast.makeText(this, "Disimpan ke Bookmark!", Toast.LENGTH_SHORT).show()
                        }
                    }
                    4 -> {
                        val histString = if(history.isEmpty()) "Kosong" else history.joinToString("\n")
                        AlertDialog.Builder(this).setTitle("History").setMessage(histString).show()
                    }
                }
            }.show()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val currentWeb = tabManager.getCurrentTab()
        if (currentWeb?.canGoBack() == true) {
            currentWeb.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
