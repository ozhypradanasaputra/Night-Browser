package com.nightbrowse.app

import android.net.Uri

object AdBlocker {
    var isEnabled = true
    var adsBlockedCount = 0

    private val blockedHosts = hashSetOf(
        "doubleclick.net", "google-analytics.com", "googlesyndication.com",
        "googleadservices.com", "adservice.google.com", "analytics.google.com",
        "ads.youtube.com", "adserver.com", "popads.net", "popcash.net",
        "onclickads.net", "adsterra.com", "exoclick.com", "juicyads.com",
        "daumcdn.net", "adnxs.com", "pubmatic.com", "rubiconproject.com",
        "criteo.com", "casalemedia.com", "openx.net", "adtech.de"
    )

    fun shouldBlock(url: String): Boolean {
        if (!isEnabled) return false
        return try {
            val host = Uri.parse(url).host ?: return false
            val blocked = blockedHosts.any { host.contains(it) }
            if (blocked) {
                adsBlockedCount++
            }
            blocked
        } catch (e: Exception) {
            false
        }
    }
}
