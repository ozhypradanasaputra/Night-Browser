package com.nightbrowse.app

import android.content.Context
import android.webkit.WebView

class TabManager(private val context: Context) {
    private val tabs = mutableListOf<WebView>()
    var currentTabIndex = -1
        private set

    fun createNewTab(creator: () -> WebView): WebView {
        val webView = creator()
        tabs.add(webView)
        currentTabIndex = tabs.size - 1
        return webView
    }

    fun getCurrentTab(): WebView? {
        if (currentTabIndex in tabs.indices) {
            return tabs[currentTabIndex]
        }
        return null
    }

    fun switchTab(index: Int): WebView? {
        if (index in tabs.indices) {
            currentTabIndex = index
            return tabs[index]
        }
        return null
    }

    fun closeTab(index: Int) {
        if (index in tabs.indices) {
            val wv = tabs.removeAt(index)
            wv.destroy()
            if (currentTabIndex >= tabs.size) {
                currentTabIndex = tabs.size - 1
            }
        }
    }

    fun getTabCount(): Int = tabs.size
}
